package com.raven.menu;

public interface EventMenuSelected {

    public void menuSelected(int index);
}
